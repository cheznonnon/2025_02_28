//
//  Nonnon_Blank_ScreensaverView.h
//  Nonnon Blank Screensaver
//
//  Created by のんのん on 2023/06/25.
//

#import <ScreenSaver/ScreenSaver.h>

@interface Nonnon_Blank_ScreensaverView : ScreenSaverView

@end
